import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { AuthProvider } from "./src/Context/AuthProvider";

// Screens
import LoginScreen from "./src/Screens/LoginScreen";
import RegisterScreen from "./src/Screens/RegisterScreen";
import HomeScreen from "./src/Screens/HomeScreen";
import Enable2FAScreen from "./src/Screens/Enable2FAScreen";
import QRGeneratorScreen from "./src/Screens/QRGeneratorScreen";
import OTPVerificationScreen from "./src/Screens/OTPVerification";
import SettingsScreen from "./src/Screens/SettingsScreen";
import BiometricAuthScreen from "./src/Screens/BiometericAuthScreen";

const Stack = createStackNavigator();

const App = () => {
  return (
    <AuthProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Login">
          <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
          <Stack.Screen name="Register" component={RegisterScreen} options={{ title: "Register" }} />
          <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
          <Stack.Screen name="Enable2FA" component={Enable2FAScreen} options={{ title: "Enable 2FA" }} />
          <Stack.Screen name="QRGenerator" component={QRGeneratorScreen} options={{ title: "Generate QR Code" }} />
          <Stack.Screen name="OTPVerification" component={OTPVerificationScreen} options={{ title: "Verify OTP" }} />
          <Stack.Screen name="Settings" component={SettingsScreen} options={{ title: "Settings" }} />
          <Stack.Screen name="BiometricAuth" component={BiometricAuthScreen} options={{ title: "Biometric Authentication" }} />
        </Stack.Navigator>
      </NavigationContainer>
    </AuthProvider>
  );
};

export default App;
