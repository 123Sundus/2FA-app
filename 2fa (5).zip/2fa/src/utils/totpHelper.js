import * as OTPAuth from "otpauth";
import { getRandomBytes } from "expo-random";
import * as base32 from "thirty-two";

// Generates a Base32-encoded secret
export const generateSecret = async () => {
  const randomBuffer = await getRandomBytes(10);
  const base32Secret = base32.encode(randomBuffer).toString().replace(/=/g, "").replace(/\r?\n|\r/g, "");
  return base32Secret.toUpperCase(); // Converts to uppercase
};

// Generate OTPAuth URL for Google/Microsoft Authenticator
export const generateOTPAuthURL = (email, secret) => {
  return `otpauth://totp/2FA-App:${email}?secret=${secret}&issuer=2FA-App&algorithm=SHA1&digits=6&period=30`;
};

// Verifys OTP using the same secret
export const verifyOTP = (otp, secret) => {
  const totp = new OTPAuth.TOTP({
    secret: OTPAuth.Secret.fromBase32(secret),
    algorithm: "SHA1",
    digits: 6,
    period: 30,
  });

  return totp.validate({ token: otp }) !== null;
};
