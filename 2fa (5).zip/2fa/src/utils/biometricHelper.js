import * as LocalAuthentication from 'expo-local-authentication';


export const isBiometricAvailable = async () => {
    try {
        const hasHardware = await LocalAuthentication.hasHardwareAsync();
        const isEnrolled = await LocalAuthentication.isEnrolledAsync();

        if (!hasHardware) {
            console.log("Biometric authentication is not supported on this device.");
            return false;
        }
        if (!isEnrolled) {
            console.log("No biometrics are enrolled on this device.");
            return false;
        }

        return true;
    } catch (error) {
        console.error("Error checking biometric support:", error);
        return false;
    }
};


export const authenticateWithBiometrics = async () => {
    try {
        const result = await LocalAuthentication.authenticateAsync({
            promptMessage: "Authenticate with Biometrics",
            cancelLabel: "Cancel",
            fallbackLabel: "Use Passcode",
            disableDeviceFallback: false, // Allowing passcode fallback if biometrics fail.
        });

        return result.success;
    } catch (error) {
        console.error("Biometric authentication failed:", error);
        return false;
    }
};