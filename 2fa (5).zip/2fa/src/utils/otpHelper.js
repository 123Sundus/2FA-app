import * as Crypto from "expo-crypto";

/**
 * Generates a 6-digit OTP using a secure random function.
 * @returns {string} - The generated OTP.
 */
export const generateOTP = () => {
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  return otp;
};

/**
 * Generates a Time-Based One-Time Password (TOTP).
 * @param {string} secret - The secret key for the user.
 * @param {number} timeStep - Time step in seconds (default: 30s).
 * @returns {Promise<string>} - A 6-digit OTP.
 */
export const generateTOTP = async (secret, timeStep = 30) => {
  const time = Math.floor(Date.now() / 1000 / timeStep);
  const message = `${time}`;
  
  const hmac = await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    message + secret
  );

  const otp = parseInt(hmac.substring(0, 6), 16) % 1000000;
  return otp.toString().padStart(6, "0");
};

/**
 * Validates if the given OTP is correct.
 * @param {string} inputOTP - The OTP entered by the user.
 * @param {string} generatedOTP - The correct OTP.
 * @returns {boolean} - Whether the OTP is valid.
 */
export const validateOTP = (inputOTP, generatedOTP) => {
  return inputOTP === generatedOTP;
};
