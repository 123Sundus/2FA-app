import * as SecureStore from 'expo-secure-store';

/**
 * Check if SecureStore is available on the device.
 * @returns {boolean}
 */
const isSecureStoreAvailable = async () => {
  try {
    return await SecureStore.isAvailableAsync();
  } catch (error) {
    console.error('SecureStore availability check failed:', error);
    return false;
  }
};

/**
 * Save a password securely.
 * @param {string} account - The account name or identifier.
 * @param {string} password - The password or 2FA secret to be stored.
 * @returns {Promise<boolean>} - True if saved successfully, false otherwise.
 */
export const saveAccountPassword = async (account, password) => {
  if (!(await isSecureStoreAvailable())) {
    console.error('SecureStore is not available on this device.');
    return false;
  }

  try {
    await SecureStore.setItemAsync(account, btoa(password)); // Encode password
    return true;
  } catch (error) {
    console.error('Error saving password:', error);
    return false;
  }
};

/**
 * Retrieve a stored password.
 * @param {string} account - The identifier used to store the password.
 * @returns {Promise<string | null>} - The stored password or null if not found.
 */
export const getAccountPassword = async (account) => {
  if (!(await isSecureStoreAvailable())) return null;

  try {
    const storedPassword = await SecureStore.getItemAsync(account);
    return storedPassword ? atob(storedPassword) : null; // Decode password
  } catch (error) {
    console.error('Error retrieving password:', error);
    return null;
  }
};

/**
 * Delete a stored password.
 * @param {string} account - The identifier of the password to delete.
 * @returns {Promise<boolean>} - True if deleted successfully, false otherwise.
 */
export const deleteAccountPassword = async (account) => {
  if (!(await isSecureStoreAvailable())) return false;

  try {
    await SecureStore.deleteItemAsync(account);
    return true;
  } catch (error) {
    console.error('Error deleting password:', error);
    return false;
  }
};

/**
 * Generate a strong random password.
 * @param {number} length - The length of the password.
 * @returns {string} - A randomly generated secure password.
 */
export const generateSecurePassword = (length = 16) => {
  const characters =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+';
  let password = '';
  for (let i = 0; i < length; i++) {
    password += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return password;
};