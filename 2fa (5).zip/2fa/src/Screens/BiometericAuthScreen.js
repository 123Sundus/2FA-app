import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Alert, StyleSheet, Platform } from 'react-native';
import * as LocalAuthentication from 'expo-local-authentication';

const BiometricAuthScreen = ({ navigation }) => {
    const [isBiometricAvailable, setIsBiometricAvailable] = useState(false);

    useEffect(() => {
        const checkBiometricAvailability = async () => {
            if (Platform.OS === 'web') {
                setIsBiometricAvailable(false); 
                return;
            }

            const hasHardware = await LocalAuthentication.hasHardwareAsync();
            const isEnrolled = await LocalAuthentication.isEnrolledAsync();
            setIsBiometricAvailable(hasHardware && isEnrolled);
        };

        checkBiometricAvailability();
    }, []);

    const handleBiometricAuth = async () => {
        if (Platform.OS === 'web') {
            Alert.alert("Unsupported", "Biometric authentication is not supported on the web.");
            return;
        }

        const result = await LocalAuthentication.authenticateAsync({
            promptMessage: 'Authenticate with Biometrics',
            fallbackLabel: 'Use Passcode',
        });

        if (result.success) {
            Alert.alert('Success', 'Biometric Authentication Successful!');
            navigation.replace('Home'); 
        } else {
            Alert.alert('Authentication Failed', 'Please try again.');
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Biometric Authentication</Text>
            <TouchableOpacity 
                style={[styles.button, !isBiometricAvailable && styles.disabledButton]} 
                onPress={handleBiometricAuth}
                disabled={!isBiometricAvailable}
            >
                <Text style={styles.buttonText}>
                    {isBiometricAvailable ? "Authenticate with Biometrics" : "Biometrics Not Available"}
                </Text>
            </TouchableOpacity>
        </View>
    );
};

export default BiometricAuthScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f8f9fa',
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    button: {
        backgroundColor: '#007bff',
        padding: 15,
        borderRadius: 10,
        marginTop: 10,
    },
    disabledButton: {
        backgroundColor: '#6c757d',
    },
    buttonText: {
        color: '#fff',
        fontSize: 16,
    },
});