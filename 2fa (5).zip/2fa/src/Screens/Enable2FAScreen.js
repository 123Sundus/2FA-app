import React, { useState } from "react";
import { View, Text, TextInput, Button } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { generateSecret } from "../utils/totpHelper";

const Enable2FAScreen = () => {
  const [email, setEmail] = useState("");
  const navigation = useNavigation();

  const handleEnable2FA = () => {
    if (email) {
      const secret = generateSecret();
      navigation.navigate("QRGenerator", { email, secret });
    }
  };

  return (
    <View>
      <Text>Enter your email to enable 2FA:</Text>
      <TextInput placeholder="Email" value={email} onChangeText={setEmail} />
      <Button title="Enable 2FA" onPress={handleEnable2FA} />
    </View>
  );
};

export default Enable2FAScreen;
