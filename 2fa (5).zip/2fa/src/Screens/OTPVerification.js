import React, { useState } from "react";
import { View, Text, TextInput, Button } from "react-native";
import { verifyOTP } from "../utils/totpHelper";

const OTPVerificationScreen = ({ route }) => {
  const { secret } = route.params;
  const [otp, setOtp] = useState("");
  const [message, setMessage] = useState("");

  const handleVerify = () => {
    if (verifyOTP(otp, secret)) {
      setMessage("OTP Verified Successfully!");
    } else {
      setMessage("Invalid OTP. Try again.");
    }
  };

  return (
    <View>
      <Text>Enter OTP:</Text>
      <TextInput value={otp} onChangeText={setOtp} placeholder="Enter OTP" />
      <Button title="Verify OTP" onPress={handleVerify} />
      <Text>{message}</Text>
    </View>
  );
};

export default OTPVerificationScreen;