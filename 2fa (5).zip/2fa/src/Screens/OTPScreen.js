import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';

const OtpScreen = ({ route, navigation }) => {
    const { email } = route.params; 
    const [otp, setOtp] = useState('');

    const handleOtpVerification = () => {
        
        if (!otp) {
            Alert.alert("⚠️ Error", "Please enter the OTP");
            return;
        }

        
        if (otp === '123456') { // Example if the OTP matches '123456'
            Alert.alert("✅ OTP Verified", "You have successfully logged in!");
            navigation.navigate('Home'); 
        } else {
            Alert.alert("❌ Invalid OTP", "The OTP entered is incorrect.");
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Enter OTP</Text>
            <TextInput
                style={styles.input}
                placeholder="Enter OTP"
                value={otp}
                onChangeText={setOtp}
                keyboardType="numeric"
                maxLength={6}
            />
            <TouchableOpacity style={styles.button} onPress={handleOtpVerification}>
                <Text style={styles.buttonText}>VERIFY OTP</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
    input: { width: '80%', borderWidth: 1, padding: 10, marginBottom: 10, borderRadius: 5 },
    button: { backgroundColor: 'blue', padding: 10, borderRadius: 5 },
    buttonText: { color: 'white', fontWeight: 'bold' },
});

export default OtpScreen;
