import React, { useState, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet, ImageBackground } from 'react-native';
import { AuthContext } from '../Context/AuthProvider';

const backgroundImage = require('../assets/background.jpg'); 

const SignupScreen = ({ navigation }) => {
  const { signup } = useContext(AuthContext);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignup = async () => {
    if (!email || !password) {
      Alert.alert("Error", "Please enter both email and password.");
      return;
    }

    const result = await signup(email, password);
    if (result.success) {
      Alert.alert("Success", "Registration successful! Please log in.");
      navigation.navigate('Login');
    } else {
      Alert.alert("Error", result.message);
    }
  };

  return (
    <ImageBackground source={backgroundImage} style={styles.background}>
      <View style={styles.container}>
        <Text style={styles.title}>Register</Text>
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
        />
        <TextInput
          style={styles.input}
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />
        <TouchableOpacity style={styles.button} onPress={handleSignup}>
          <Text style={styles.buttonText}>SIGN UP</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <Text style={styles.registerText}>Already have an account? Login</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: { flex: 1, width: '100%', height: '100%', resizeMode: 'cover' },
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20, backgroundColor: 'rgba(0, 0, 0, 0.5)' },
  title: { fontSize: 30, fontWeight: 'bold', color: 'white', marginBottom: 20 },
  input: { width: '80%', backgroundColor: 'white', padding: 10, borderRadius: 5, marginBottom: 10 },
  button: { backgroundColor: 'blue', padding: 10, borderRadius: 5, marginTop: 10, width: '80%', alignItems: 'center' },
  buttonText: { color: 'white', fontWeight: 'bold' },
  registerText: { color: 'white', marginTop: 10, textDecorationLine: 'underline' },
});

export default SignupScreen;
