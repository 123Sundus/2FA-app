import React, { useState, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet } from "react-native";
import * as SecureStore from "expo-secure-store";
import { generateTOTP, verifyTOTP } from "../utils/totpHelper";

const AuthenticatorScreen = () => {
  const [otp, setOtp] = useState("");
  const [secret, setSecret] = useState("");
  const [enteredOtp, setEnteredOtp] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    const loadSecret = async () => {
      try {
        const storedSecret = await SecureStore.getItemAsync("totp_secret");
        if (storedSecret) {
          setSecret(storedSecret);
          updateOTP(storedSecret);
          setError("");
        } else {
          setError("No secret key found. Please set up 2FA.");
        }
      } catch (err) {
        console.error("Error loading secret:", err);
        setError("Failed to retrieve secret key.");
      }
    };

    loadSecret();

    let interval;
    if (secret) {
      interval = setInterval(() => updateOTP(secret), 30000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [secret]);

  const updateOTP = (secretKey) => {
    if (secretKey) {
      const newOtp = generateTOTP(secretKey);
      setOtp(newOtp);
    }
  };

  const handleVerifyOTP = () => {
    if (!enteredOtp) {
      Alert.alert("⚠️ Error", "Please enter an OTP.");
      return;
    }

    if (verifyTOTP(secret, enteredOtp)) {
      Alert.alert("✅ Success", "OTP is valid!");
    } else {
      Alert.alert("❌ Error", "Invalid OTP. Please try again.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Authenticator</Text>

      {error ? (
        <Text style={styles.errorText}>{error}</Text>
      ) : (
        <>
          <Text style={styles.label}>Generated OTP:</Text>
          <Text style={styles.otp}>{otp || "Generating..."}</Text>

          <Text style={styles.label}>Enter OTP:</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter OTP"
            value={enteredOtp}
            onChangeText={setEnteredOtp}
            keyboardType="numeric"
          />

          <TouchableOpacity style={styles.button} onPress={handleVerifyOTP}>
            <Text style={styles.buttonText}>Verify OTP</Text>
          </TouchableOpacity>
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  label: {
    fontSize: 18,
    marginBottom: 5,
  },
  otp: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#007bff",
    marginBottom: 20,
  },
  input: {
    width: "80%",
    height: 50,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    paddingHorizontal: 10,
    fontSize: 18,
    marginBottom: 20,
    textAlign: "center",
  },
  button: {
    backgroundColor: "#007bff",
    padding: 15,
    borderRadius: 8,
    width: "80%",
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
  errorText: {
    color: "red",
    fontSize: 16,
    textAlign: "center",
    marginBottom: 10,
  },
});

export default AuthenticatorScreen;
