import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, Alert, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Button } from 'react-native-paper';

const TrustedDevicesScreen = ({ navigation }) => {
  const [trustedDevices, setTrustedDevices] = useState([]);

  useEffect(() => {
    const fetchTrustedDevices = async () => {
      try {
        const storedDevices = await AsyncStorage.getItem('trustedDevices');
        if (storedDevices) {
          setTrustedDevices(JSON.parse(storedDevices));
        }
      } catch (error) {
        console.error('Error fetching trusted devices:', error);
      }
    };

    fetchTrustedDevices();
  }, []);

  const removeDevice = async (deviceId) => {
    try {
      const updatedDevices = trustedDevices.filter(device => device.id !== deviceId);
      await AsyncStorage.setItem('trustedDevices', JSON.stringify(updatedDevices));
      setTrustedDevices(updatedDevices);
      Alert.alert('Success', 'Device removed successfully.');
    } catch (error) {
      console.error('Error removing device:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Trusted Devices</Text>
      {trustedDevices.length === 0 ? (
        <Text style={styles.noDevicesText}>No trusted devices found.</Text>
      ) : (
        <FlatList
          data={trustedDevices}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.deviceItem}>
              <Text style={styles.deviceText}>{item.name} ({item.id})</Text>
              <TouchableOpacity style={styles.removeButton} onPress={() => removeDevice(item.id)}>
                <Text style={styles.removeButtonText}>Remove</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}
      <Button mode="contained" onPress={() => navigation.goBack()} style={styles.backButton}>
        Back
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  noDevicesText: {
    fontSize: 16,
    color: 'gray',
  },
  deviceItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    backgroundColor: '#fff',
    borderRadius: 8,
    marginBottom: 10,
  },
  deviceText: {
    fontSize: 16,
    color: '#333',
  },
  removeButton: {
    backgroundColor: '#d9534f',
    padding: 8,
    borderRadius: 5,
  },
  removeButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  backButton: {
    marginTop: 20,
    width: '100%',
  },
});

export default TrustedDevicesScreen;