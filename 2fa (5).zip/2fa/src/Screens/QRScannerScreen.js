import React, { useState } from "react";
import { View, Text, TextInput, Button } from "react-native";
import OTPAuth from "otpauth";

const QRScannerScreen = () => {
  const [enteredOTP, setEnteredOTP] = useState("");
  const [isVerified, setIsVerified] = useState(false);

  const verifyOTP = () => {
   
    const secret = "YOUR_SECRET_HERE";
    const totp = new OTPAuth.TOTP({ secret, algorithm: "SHA1", digits: 6, period: 30 });
    const expectedOTP = totp.generate();

    if (enteredOTP === expectedOTP) {
      setIsVerified(true);
    } else {
      setIsVerified(false);
    }
  };

  return (
    <View>
      <Text>Enter OTP from Google/Microsoft Authenticator</Text>
      <TextInput
        value={enteredOTP}
        onChangeText={setEnteredOTP}
        keyboardType="numeric"
        placeholder="Enter OTP"
      />
      <Button title="Verify OTP" onPress={verifyOTP} />
      {isVerified ? <Text>✅ OTP Verified!</Text> : <Text>❌ Invalid OTP</Text>}
    </View>
  );
};

export default QRScannerScreen;