import React, { useState, useEffect } from "react";
import { View, Text, TextInput, Button } from "react-native";
import QRCode from "react-native-qrcode-svg";
import { generateSecret, generateOTPAuthURL } from "../utils/totpHelper";

const QRGeneratorScreen = ({ navigation }) => {
  const [email, setEmail] = useState("");
  const [secret, setSecret] = useState("");
  const [otpAuthUrl, setOtpAuthUrl] = useState("");

  useEffect(() => {
    const setupTOTP = async () => {
      if (email) {
        const newSecret = await generateSecret();
        setSecret(newSecret);
        const otpUrl = generateOTPAuthURL(email, newSecret);
        setOtpAuthUrl(otpUrl);
      }
    };
    setupTOTP();
  }, [email]);

  return (
    <View>
      <Text>Enter your Email:</Text>
      <TextInput value={email} onChangeText={setEmail} placeholder="Enter Email" />
      {otpAuthUrl ? (
        <QRCode value={otpAuthUrl} size={200} />
      ) : (
        <Text>No QR Code yet.</Text>
      )}
      <Button 
        title="Go to OTP Verification" 
        onPress={() => navigation.navigate("OTPVerification", { secret })} 
      />
      <Button title="Back" onPress={() => navigation.goBack()} />
    </View>
  );
};

export default QRGeneratorScreen;
