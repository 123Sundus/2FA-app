import React, { createContext, useState, useRef } from "react";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const usersRef = useRef([]); // Stores registered users.

  const register = (email, password) => {
    console.log("🔹 Registering:", email);

    if (usersRef.current.some((u) => u.email === email)) {
      console.log("⚠️ User already exists:", usersRef.current);
      return { success: false, message: "User already exists" };
    }

    usersRef.current.push({ email, password });
    console.log("✅ Registered successfully:", usersRef.current);
    return { success: true };
  };

  const login = (email, password) => {
    console.log("🔵 Login attempt:", email, password);
    console.log("🗂 Stored users:", usersRef.current);

    const foundUser = usersRef.current.find((u) => u.email === email && u.password === password);
    if (foundUser) {
      setIsAuthenticated(true);
      setUser({ email });

      console.log("✅ Login successful:", email);
      return { success: true };
    } else {
      console.log("❌ Invalid login attempt");
      return { success: false, message: "Invalid email or password" };
    }
  };

  return (
    <AuthContext.Provider value={{ register, login, isAuthenticated, user }}>
      {children}
    </AuthContext.Provider>
  );
};
