import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import LoginScreen from "../Screens/LoginScreen";
import RegisterScreen from "../Screens/RegisterScreen";
import QRGeneratorScreen from "../Screens/QRGeneratorScreen"; 
import OTPVerificationScreen from "../Screens/OTPVerification";
import HomeScreen from "../Screens/HomeScreen";

const Stack = createStackNavigator();

const AppNavigator = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login" screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Register" component={RegisterScreen} />
        
        {}
        <Stack.Screen 
          name="QRGenerator" 
          component={QRGeneratorScreen} 
          options={{ title: "Scan QR with Authenticator", headerShown: true }} 
        />

        {}
        <Stack.Screen 
          name="OTPVerification" 
          component={OTPVerificationScreen} 
          options={{ title: "Enter OTP", headerShown: true }} 
        />

        <Stack.Screen name="Home" component={HomeScreen} options={{ title: "Home", headerShown: true }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;
