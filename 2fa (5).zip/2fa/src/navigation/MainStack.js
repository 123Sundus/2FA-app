import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import HomeScreen from "../Screens/HomeScreen";
import SettingsScreen from "../Screens/SettingsScreen";
import Enable2FAScreen from "../Screens/Enable2FAScreen";
import BiometricAuthScreen from "../Screens/BiometericAuthScreen"; 
import TrustedDevicesScreen from "../Screens/TrustedDevicesScreen";

const Stack = createStackNavigator();

const MainStack = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
      <Stack.Screen name="Enable2FA" component={Enable2FAScreen} />
      <Stack.Screen name="BiometricAuth" component={BiometricAuthScreen} />
      <Stack.Screen name="TrustedDevices" component={TrustedDevicesScreen} />
    </Stack.Navigator>
  );
};

export default MainStack;