import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import * as LocalAuthentication from 'expo-local-authentication';
import { storePassword, retrievePassword, generateSecurePassword } from '../utils/passwordManagerHelper';

const PasswordManager = () => {
  const [service, setService] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSavePassword = async () => {
    if (!service || !username || !password) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }
    await storePassword(service, username, password);
    Alert.alert('Success', 'Password saved securely');
    setService('');
    setUsername('');
    setPassword('');
  };

  const handleRetrievePassword = async () => {
    const auth = await LocalAuthentication.authenticateAsync({ promptMessage: 'Authenticate to retrieve passwords' });
    if (!auth.success) {
      Alert.alert('Authentication Failed', 'Could not verify your identity');
      return;
    }
    const storedPassword = await retrievePassword(service);
    if (storedPassword) {
      setPassword(storedPassword);
    } else {
      Alert.alert('Error', 'No password found for this service');
    }
  };

  const handleGeneratePassword = () => {
    setPassword(generateSecurePassword());
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Service Name</Text>
      <TextInput style={styles.input} value={service} onChangeText={setService} placeholder="e.g., Gmail" />
      
      <Text style={styles.label}>Username</Text>
      <TextInput style={styles.input} value={username} onChangeText={setUsername} placeholder="Enter username" />
      
      <Text style={styles.label}>Password</Text>
      <TextInput style={styles.input} value={password} onChangeText={setPassword} placeholder="Enter password" secureTextEntry />
      
      <TouchableOpacity style={styles.button} onPress={handleGeneratePassword}>
        <Text style={styles.buttonText}>Generate Secure Password</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={styles.button} onPress={handleSavePassword}>
        <Text style={styles.buttonText}>Save Password</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={styles.button} onPress={handleRetrievePassword}>
        <Text style={styles.buttonText}>Retrieve Password</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    borderRadius: 5,
    marginTop: 5,
  },
  button: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

export default PasswordManager;
