import React from "react";
import { View, Text, StyleSheet } from "react-native";
import QRCode from "react-native-qrcode-svg";
import OTPAuth from "otpauth";

const GoogleAuthQRCode = ({ secret, accountName, issuer }) => {
  if (!secret || !accountName || !issuer) {
    return <Text style={styles.errorText}>Invalid QR Code data.</Text>;
  }

  // Generates the OTPAuth URL (Google Authenticator-compatible)
  const otpAuth = new OTPAuth.TOTP({
    issuer: issuer,
    label: accountName,
    algorithm: "SHA1",
    digits: 6,
    period: 30,
    secret: secret, // Secret Base32 encoded
  });

  const otpAuthURL = otpAuth.toString();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Scan this QR Code in Google Authenticator</Text>
      <QRCode value={otpAuthURL} size={200} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    marginTop: 20,
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 10,
  },
  errorText: {
    color: "red",
    fontSize: 14,
  },
});

export default GoogleAuthQRCode;
