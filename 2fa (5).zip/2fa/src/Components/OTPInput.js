import React, { useRef, useState } from "react";
import { View, TextInput, StyleSheet } from "react-native";

const OTPInput = ({ length = 6, onOTPChange }) => {
  const [otpArray, setOtpArray] = useState(Array(length).fill(""));
  const inputRefs = useRef([]);

  const handleChange = (text, index) => {
    const newOtpArray = [...otpArray];
    newOtpArray[index] = text;
    setOtpArray(newOtpArray);
    onOTPChange(newOtpArray.join(""));

   
    if (text && index < length - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyPress = (e, index) => {
    if (e.nativeEvent.key === "Backspace" && !otpArray[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  return (
    <View style={styles.container}>
      {otpArray.map((_, index) => (
        <TextInput
          key={index}
          ref={(el) => (inputRefs.current[index] = el)}
          style={styles.input}
          maxLength={1}
          keyboardType="number-pad"
          value={otpArray[index]}
          onChangeText={(text) => handleChange(text, index)}
          onKeyPress={(e) => handleKeyPress(e, index)}
        />
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    justifyContent: "center",
    marginVertical: 10,
  },
  input: {
    width: 40,
    height: 50,
    marginHorizontal: 5,
    borderWidth: 2,
    borderColor: "#007bff",
    textAlign: "center",
    fontSize: 20,
    borderRadius: 5,
    backgroundColor: "#fff",
  },
});

export default OTPInput;